# Telas de AMOSTRA do Sentinel

Telas só de frontend, com dados falsos, para o grupo ver a cara completa do sistema. Nada grava, nada consulta banco, nada exige login.

## Como instalar
1. Na raiz do projeto (base: branch `Manveru`), copie as pastas deste pacote por cima, mantendo os caminhos.
2. Aplique a mudança em `routes/web.php` (arquivo `routes-web.patch`, ou cole as 3 linhas do final do arquivo):
   ```php
   if (! app()->environment('production')) {
       require __DIR__.'/amostra.php';
   }
   ```
3. `php artisan serve` e abra `http://127.0.0.1:8000/amostra` (índice das 44 telas).

## Como usar
- Toda tela tem a faixa **AMOSTRA** e o título "[AMOSTRA] …".
- "Ver como: leitura | operador | admin" (ou `?papel=admin`) muda menu e permissões.
- Segurar para confirmar: 2 s. Soltar antes mostra "Nada foi gravado".
- Estados do agente: `/amostra/agente/{estado}` (22 estados, listados no índice).
- Modais: `?modal=reautenticacao|conflito|exclusao|exclusao-fisica`.

## Arquivos
- `app/Amostra/DadosAmostra.php` — único lugar com dados falsos (e o inventário).
- `app/Http/Controllers/AmostraController.php`, `routes/amostra.php`
- `resources/views/amostra/**`, `public/amostra/amostra.{css,js}`

## Para remover depois
Apague esses arquivos e as 3 linhas do `routes/web.php`. Nada mais depende deles.

## Verificado
Render de 255 combinações (tela × papel), 348 links internos sem erro, sem rolagem horizontal em 375 px, hold de 2 s e modais testados em Chromium. **Não** foi rodado dentro do Laravel (o sandbox tem PHP 8.3 e o vendor exige 8.4.1): teste no seu ambiente.
