<?php

namespace App\Services;

use App\Models\AuditLog;
use Illuminate\Support\Str;

/**
 * Ponto único de gravação em audit_logs (RF06/RF07). Toda execução ou
 * tentativa negada de tool do AiAgentService passa por aqui.
 */
class AuditoriaService
{
    /**
     * @param  string  $resultado  'sucesso' | 'erro' (falha técnica) | 'recusado' (regra de negócio) | 'negado' (RBAC/whitelist)
     */
    public function registrar(
        string $tool,
        string $acao,
        ?string $entidadeTipo,
        ?int $entidadeId,
        array $parametros,
        string $resultado,
        ?string $mensagem,
        string $papel,
        bool $permitido,
    ): AuditLog {
        return AuditLog::create([
            'user_id' => null, // sem autenticação (RF10): quem agiu é o "papel", não um usuário
            'tool' => $tool,
            'acao' => $acao,
            'entidade_tipo' => $entidadeTipo,
            'entidade_id' => $entidadeId,
            'parametros' => $parametros,
            'resultado' => $resultado,
            'mensagem' => $mensagem === null ? null : Str::limit($mensagem, 250, ''),
            'papel' => $papel,
            'permitido' => $permitido,
            'tenant_id' => (int) config('sentinel.tenant_atual'),
        ]);
    }
}
